//
//  ImageType.swift
//  Woods-JWA
//
//  Created by Johannes Ahlborn on 30.01.24.
//

import Foundation

enum ImageType {
    case imgCD, imgCD2, imgCD3
}
