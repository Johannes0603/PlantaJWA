//
//  Woods_JWAApp.swift
//  Woods-JWA
//
//  Created by Johannes Ahlborn on 10.01.24.
//

import SwiftUI

@main
struct Woods_JWAApp: App {
    var body: some Scene {
        WindowGroup {
            NavigatorView()
        }
    }
}
